package ku.piii.musictableviewfxml;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.concurrent.CountDownLatch;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.embed.swing.JFXPanel;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.MenuBar;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TablePosition;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;
import javafx.scene.input.InputEvent;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import java.awt.Desktop;
import java.net.URI;
import java.net.URISyntaxException;
//-----------------------------------------------------------------
import ku.piii.model.MusicMedia;
import ku.piii.model.MusicMediaCollection;
import ku.piii.model.MusicMediaColumnInfo;
import ku.piii.music.MusicService;
import ku.piii.music.MusicServiceFactory;


public class FXMLController implements Initializable {
    

    String pathScannedOnLoad = "../test-music-files/";
    public String pathresult = null;
    public String artistname = null;
    public String tracktitle = null;
    FileChooser fileC = new FileChooser();
    private final static MusicService MUSIC_SERVICE = MusicServiceFactory.getMusicServiceInstance();

    ObservableList<MusicMedia> dataForTableView = FXCollections.observableArrayList();
    public static ArrayList<MusicMedia> List = new ArrayList<>();

    public static void outputFile() {
    
        for (MusicMedia musicmedia : List) {

            System.out.println("Name: " + musicmedia.getTitle()+ "\n"
                    + " Comment: " + musicmedia.getComments() + "\n"
                    + " Genre: " + musicmedia.getGenre()+ "\n"
                    + " Year: " + musicmedia.getYear()+ "\n"
                    + " Path: " + musicmedia.getPath() + "\n"); 
            }
    } 
    
    @FXML
    private Label addressBook;

    @FXML
    TableView<MusicMedia> tableView;

    FilteredList<MusicMedia> filteredData;


    @FXML
    private void handleNewAction(ActionEvent event){
        for ( int i = 0; i<tableView.getItems().size(); i++) {
            tableView.getItems().clear();
        }
    }
    
    public MediaPlayer mediaPlayer;
    public MediaPlayer nextPlayer;  
    
    @FXML
    private void Stopbtn(ActionEvent actionEvent){
        if (mediaPlayer != null){
            mediaPlayer.stop();
        }
    }
    
      
   @FXML
    private void PlayBtn(ActionEvent actionEvent){
        final CountDownLatch latch = new CountDownLatch(1);
    SwingUtilities.invokeLater(() -> {
        new JFXPanel();
        latch.countDown();
    });
     try{
         latch.await();
     }catch (InterruptedException ex){
         Logger.getLogger(FXMLController.class.getName()).log(Level.SEVERE, null, ex);
     }
        String replaced = pathresult.replace("\\", "/");
        Media media = new Media(new File(replaced).toURI().toString());
        
        mediaPlayer = new MediaPlayer(media);
        mediaPlayer.play();
    }
    
    @FXML
    private void Youtubebtn(ActionEvent actionEvent){
       Youtube();
    }

    public String result = null;

    
    public Object value;
    
    
   @FXML
    private void Youtube(){
                    Desktop tube = Desktop.getDesktop();
                    try {
                        tube.browse(new URI("https://www.youtube.com/results?search_query="+tracktitle+"+by+"+artistname));
                    } catch (IOException ex) {
                        Logger.getLogger(FXMLController.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (URISyntaxException ex) {
                        Logger.getLogger(FXMLController.class.getName()).log(Level.SEVERE, null, ex);
                    }
    }
    
    public void handleYoutubeselection()
    {
        tableView.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue observableValue, Object oldValue, Object newValue) {
                if (tableView.getSelectionModel().getSelectedItem() != null) {
                    TableView.TableViewSelectionModel selectionModel = tableView.getSelectionModel();
                    ObservableList selectedCells1 = selectionModel.getSelectedCells();
                    TablePosition tablePosition1 = (TablePosition) selectedCells1.get(0);
                    value = tablePosition1.getTableColumn().getCellData(newValue);

                    String sentence = newValue.toString();
                    String segments[] = sentence.split(",");
                    String youtubepath = pathresult;
                    youtubepath = segments[segments.length - 2];
                    System.out.println("the selected songs path is:-"+youtubepath);
                    youtubepath = segments[segments.length - 8];
                    tracktitle = youtubepath;
                    tracktitle = tracktitle.replace("Track Title: ", "");
                    tracktitle = tracktitle.replace (" ", "+");
                    System.out.println("the selected songs is: "+tracktitle);
                    youtubepath = segments[segments.length - 7];
                    artistname = youtubepath;
                    artistname = artistname.replace("Artist: ", "");
                    artistname = artistname.trim();
                    artistname = artistname.replace (" ", "+");
                    System.out.println("the selected artist is: "+artistname+"\n");
                }
                }
        });
    }
    
    
    @FXML
    private void pausebtn(ActionEvent actionEvent){
        mediaPlayer.pause();
    }

    @FXML
    private void unpausebtn(ActionEvent actionEvent){
        mediaPlayer.play();
    }
    

    @FXML
    private void handleExitAction(ActionEvent event){
        System.exit(0);
    }
    
    @FXML
    private void handleCopyAction(){

        tableView.getSelectionModel().setCellSelectionEnabled(true);
        tableView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);

        ObservableList<TablePosition> posList = tableView.getSelectionModel().getSelectedCells();
        int old_r = -1;
        StringBuilder clipboardString = new StringBuilder();
        for (TablePosition Tp : posList) {
            int r = Tp.getRow();
            int c = Tp.getColumn();
            Object cell = tableView.getColumns().get(c).getCellData(r);
            if (cell == null)
                cell = "";
            if (old_r == r)
                clipboardString.append('\t');
            else if (old_r != -1)
                clipboardString.append('\n');
            clipboardString.append(cell);
            old_r = r;
        }
        final ClipboardContent content = new ClipboardContent();
        content.putString(clipboardString.toString());
        Clipboard.getSystemClipboard().setContent(content);
    }
    
    @FXML
    private MenuBar File;
    
    
    @FXML
    private void handleSaveAction(ActionEvent event){
        tableView.refresh();
        Stage secondaryStage = new Stage();
        fileC = new FileChooser();
        fileC.setTitle("Save data");
        fileC.setInitialDirectory(new File(System.getProperty("user.home")));
        if (dataForTableView.isEmpty()){
            secondaryStage.initOwner(this.File.getScene().getWindow());
            Alert emptyTableAlert = new Alert(Alert.AlertType.ERROR, "Empty Table", ButtonType.OK);
            emptyTableAlert.setContentText("Nothing to save!");
            emptyTableAlert.initModality(Modality.APPLICATION_MODAL);
            emptyTableAlert.initOwner(this.File.getScene().getWindow());
            emptyTableAlert.showAndWait();
            if(emptyTableAlert.getResult() == ButtonType.OK){
             emptyTableAlert.close();   
            }
        }else if (dataForTableView != null){
            File file = fileC.showSaveDialog(secondaryStage);
            if (file != null){
                saveFile(tableView.getItems(), file);
            }
        }
    }
    
    public void saveFile(ObservableList<MusicMedia> dataForTableView, File file){

       try{
           try(BufferedWriter outWriter = new BufferedWriter(new FileWriter(file))){
               for (MusicMedia mm : dataForTableView){
                   outWriter.write(mm.toString());
                   outWriter.newLine();
               }
               System.out.println(dataForTableView.toString());
           }
       }catch (IOException e){
           Alert ioAlert = new Alert(Alert.AlertType.ERROR, "Wrong!", ButtonType.OK);
           ioAlert.setContentText("Sorry, error");
           ioAlert.showAndWait();
           if (ioAlert.getResult() == ButtonType.OK)
           {
               ioAlert.close();
           }
       }
}
    
    @FXML
    private void handleOpenAction(ActionEvent event){
    
    JFileChooser fileChooser = new JFileChooser();
    
    //FileFilter ft = new FileNameExtensionFilter("MP3 Files", "mp3");
    fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
    fileChooser.setAcceptAllFileFilterUsed(false);
    //fileChooser.addChoosableFileFilter(ft);
            
            if (fileChooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION){
                String pathScannedOnLoad1 = fileChooser.getSelectedFile().toString();
                final MusicMediaCollection collection = MUSIC_SERVICE
                .createMusicMediaCollection(Paths.get(pathScannedOnLoad1));
        dataForTableView.addListener(makeChangeListener(collection));
       
        if (tableView==null)
        {
            dataForTableView = FXCollections.observableArrayList(collection.getMusic());
            tableView.setItems(dataForTableView);
        }else if (tableView!=null) {
            dataForTableView.addAll(FXCollections.observableArrayList(collection.getMusic()));
            tableView.setItems(dataForTableView);
        }
            tableView.setEditable(true);
        }
    }

 
    public static void readFile(File file)
    {
        BufferedReader br = null;
        String line = "";
        String SplitBy = ",";
        
        try {
            br = new BufferedReader (new FileReader(file));
            br.readLine();
            
            while ((line = br.readLine()) != null){
                String[] MusicMedia = line.split(SplitBy);
                
                MusicMedia mm = new MusicMedia();
                mm.setTrack(MusicMedia[0]);
                mm.setPath(MusicMedia[1]);
                //mm.setLengthInSeconds(MusicMedia[2]);
                mm.setTitle(MusicMedia[3]);
                mm.setYear(MusicMedia[4]);
                mm.setGenre(MusicMedia[5]);
                mm.setComments(MusicMedia[6]);
                List.add(mm);
            }
        }catch (FileNotFoundException e) {
                  e.printStackTrace();
          } catch (IOException e) {
                  e.printStackTrace();
          } finally {
                  if (br != null) {
                          try {
                                  br.close();
                          } catch (IOException e) {
                                  e.printStackTrace();
                          }
                  }
          }
    }
    
    
     
    
    private void handleColumns() {
        List<MusicMediaColumnInfo> myColumnInfoList = TableViewFactory.makeColumnInfoList();
        TableViewFactory.makeTable(tableView, myColumnInfoList);
        tableView.setEditable(false);
    }
    

    @FXML
    TextField filter;
    String filterString;
    

    @FXML
    public void handleFilterKeyAction(ActionEvent event)
    {
        FilteredList<MusicMedia> filteredData = new FilteredList<>(dataForTableView, e -> true);
        filter.setOnKeyReleased(e -> {
            filter.textProperty().addListener((observableValue, oldValue, newValue) -> {
                filteredData.setPredicate(user -> {
                    if (newValue == null || newValue.isEmpty()) {
                        return true;
                    }
                    String lowerCaseFilter = newValue.toLowerCase();
                    if (user.getTitle().toLowerCase().contains(lowerCaseFilter)) {
                        return true;
                    } else if (user.getGenre().toLowerCase().contains(lowerCaseFilter)) {
                        return true;
                    }
                    return false;
                });
            });
            SortedList<MusicMedia> sortedData = new SortedList<>(filteredData);
            sortedData.comparatorProperty().bind(tableView.comparatorProperty());
            tableView.setItems(sortedData);
            tableView.refresh();
        });
    }

    @FXML
    private void handleAboutAction(final ActionEvent event) throws IOException {

        JOptionPane.showMessageDialog(null, "1. Please press the \"Load Files\" button to load the music files" +"\n"+
                "2. You can add more files by just pressing the \"Load Files\" button and selecting another folder with .mp3 files enclosed", "Help", 1);
            }

    @FXML
    private void handleKeyInput(final InputEvent event) {
        if (event instanceof KeyEvent) {
            final KeyEvent keyEvent = (KeyEvent) event;
            if (keyEvent.isControlDown() && keyEvent.getCode() == KeyCode.A) {
                System.out.println("Tee");
            }
        }
    }
    public Object val;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {  
        handleColumns();
        CellSelec();
        handleYoutubeselection();
        //---//
        filterString = "";
        filteredData = new FilteredList<>(dataForTableView, e -> true);
        filter.setOnKeyReleased(new EventHandler<KeyEvent>() {
            public void handle(KeyEvent ke) {
                if (ke.getCode() == KeyCode.BACK_SPACE) {
                    tableView.refresh();
                    removeKeyFromFilterString();
                    tableView.refresh();
                }
                else
                {
                    tableView.refresh();
                    addKeyToFilterString(ke.getText(), ke.isShiftDown());
                    tableView.refresh();
                }
                tableView.refresh();
                updateTableWithFilter();
                tableView.refresh();
            }
        });
    }
    

   
   @FXML
    private void CellSelec(){
    tableView.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue observableValue, Object oldValue, Object newValue) {
                if (tableView.getSelectionModel().getSelectedItem() != null) {
                    TableView.TableViewSelectionModel selectionModel = tableView.getSelectionModel();
                    ObservableList selectedCells = selectionModel.getSelectedCells();
                    TablePosition tablePosition = (TablePosition) selectedCells.get(0);
                    val = tablePosition.getTableColumn().getCellData(newValue);
                    System.out.println("Selected Value: " + val);
                    System.out.println("Selected Row: " + newValue);
                    
                    String sentence = newValue.toString();
                    String segments[] = sentence.split(",");
                    pathresult = segments[segments.length - 2];
                    System.out.println("the selected songs path is:-"+pathresult);
                    String replaced = pathresult.replace("\\", "/");
                    System.out.println("The selected song path with forwardslash:-"+replaced);
                    String thePath = replaced.replaceAll(" ","%20"); 
                    System.out.println("The selected song path that's actually recognised:-"+thePath+"\n");
       }
            }
        });
    }
    
 
    private void removeKeyFromFilterString() {
        int length = filterString.length();
        if(length>1)
            filterString = filterString.substring(0, length-1);
        else{
            filterString = "";
    }
    tableView.refresh();
    }

    private void addKeyToFilterString(String text, boolean isShiftDown) {

        if(isShiftDown)
            text = text.toUpperCase();
        filterString = filterString + text;
       System.out.println("filterString is " + filterString);

    }

    private void updateTableWithFilter() {
        filteredData = new FilteredList<>(dataForTableView, myMusicItem -> {

            if (filterString == null || filterString.length() == 0) {
                return true;
            }

            if (myMusicItem.getTitle() !=null && myMusicItem.getTitle().startsWith(filterString)) {
                return true;
            }

            if (myMusicItem.getComments() !=null && myMusicItem.getComments().startsWith(filterString)) {
                return true;
            }
            return false;
        });
        System.out.println("There are " + filteredData.size() + " elements in this list.");
        tableView.setItems(filteredData);
        tableView.refresh();
    }

    private static ListChangeListener<MusicMedia> makeChangeListener(final MusicMediaCollection collection) {
        return new ListChangeListener<MusicMedia>() {
            @Override
            public void onChanged(ListChangeListener.Change<? extends MusicMedia> change) {
                while (change.next()) {
                    if (change.wasAdded()) {
                        for (MusicMedia addedChild : change.getAddedSubList()) {
                            collection.addMusicMedia(addedChild);
                        }
                    }
                    if (change.wasRemoved()) {
                        for (MusicMedia removedChild : change.getRemoved()) {
                            collection.removeMusicMedia(removedChild);
                        }
                    }
                }
            }
        };
    }
}